#!/usr/bin/env bash
# build_archi_bundle.sh — create, sign, notarise and DMG-wrap ARCHI.app
set -euo pipefail
set -x

##############################################################################
# 0.  CONFIGURATION                                                          #
##############################################################################
APP_NAME="ARCHI"
VERSION="1.1.0"

SIGN_ID="Developer ID Application: Touch Top Notch (TEAMID)"
NOTARY_PROFILE="AC_NOTARY"

DMG_BG_REL="package/osx/dmg_bg.png"

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
BUILD_DIR="${ROOT_DIR}/build"
INSTALL_DIR="${BUILD_DIR}/install"

INFO_TEMPLATE_REL="package/rattler-build/osx/Info.plist.template"
ICNS_FILE_REL="package/rattler-build/osx/resources/Archi.icns"
ENTITLEMENTS_REL="package/rattler-build/osx/resources/entitlements.plist"

##############################################################################
# 1.  LOCATE Qt tools                                                        #
##############################################################################
QTSYS="${CONDA_PREFIX}/bin"

if   [[ -x "${QTSYS}/macdeployqt6" ]]; then
    MACDEPLOYQT="${QTSYS}/macdeployqt6"
elif [[ -x "${QTSYS}/macdeployqt"  ]]; then
    MACDEPLOYQT="${QTSYS}/macdeployqt"   # Qt ≤ 6.5 or Qt 5
else
    echo "❌  macdeployqt (Qt ≥5) not found in ${QTSYS}" >&2
    exit 1
fi
export PATH="${QTSYS}:$PATH"

##############################################################################
# 2.  CREATE clean bundle skeleton                                           #
##############################################################################
APP_DIR="${BUILD_DIR}/${APP_NAME}.app"
MACOS_DIR="${APP_DIR}/Contents/MacOS"
RES_DIR="${APP_DIR}/Contents/Resources"
FW_DIR="${APP_DIR}/Contents/Frameworks"
PLUG_DIR="${APP_DIR}/Contents/PlugIns"
QML_DIR="${APP_DIR}/Contents/qml"

rm -rf "${APP_DIR}"
mkdir -p "${MACOS_DIR}" "${RES_DIR}" "${FW_DIR}" "${PLUG_DIR}" "${QML_DIR}"

##############################################################################
# 3.  COPY main executable                                                   #
##############################################################################
cp    "${INSTALL_DIR}/bin/FreeCAD"  "${MACOS_DIR}/${APP_NAME}"
chmod +x "${MACOS_DIR}/${APP_NAME}"

##############################################################################
# 4.  PRE-COPY Qt frameworks & minimal plugins — into Resources/lib          #
##############################################################################
LIB_DIR="${RES_DIR}/lib"                       # new home for *all* dylibs
mkdir -p "${LIB_DIR}"

QT_LIB_DIRS=("${CONDA_PREFIX}/lib")
QT_PLUG_DIRS=("${QTSYS}/plugins")

# ── also scan PyPI wheels (they live in site-packages) ─────────────────────
EXTRA_QTLIB=$(python - <<'PY'
import os, site, itertools
for sp in itertools.chain(site.getsitepackages(), [site.getusersitepackages()]):
    p = os.path.join(sp, "PyQt6", "Qt6", "lib")
    if os.path.isdir(p):
        print(p); break
PY
)
if [[ -n "$EXTRA_QTLIB" ]]; then
    QT_LIB_DIRS+=("$EXTRA_QTLIB")
    QT_PLUG_DIRS+=("${EXTRA_QTLIB%/lib}/plugins")
fi

echo "Qt search paths : ${QT_LIB_DIRS[*]}"
echo "Plugin paths    : ${QT_PLUG_DIRS[*]}"

QT_MODULES=(Core Gui Widgets Network PrintSupport Svg SvgWidgets
            3DCore 3DRender 3DExtras WebEngineCore WebEngineWidgets)

shopt -s nullglob
for mod in "${QT_MODULES[@]}"; do
    found=false
    for libdir in "${QT_LIB_DIRS[@]}"; do
        for f in "${libdir}/libQt6${mod}".6*.dylib; do
            cp -av "$f" "${LIB_DIR}/"; found=true
        done
    done
    $found || echo "ℹ️  libQt6${mod}.* not found – skipped"
done
shopt -u nullglob

# ── minimal plugins (kept in PlugIns/ as before) ───────────────────────────
mkdir -p "${PLUG_DIR}/"{platforms,styles,imageformats}
for plugs in "${QT_PLUG_DIRS[@]}"; do
    [[ -e "${PLUG_DIR}/platforms/libqcocoa.dylib" ]] || \
        cp -av "${plugs}/platforms/libqcocoa.dylib" "${PLUG_DIR}/platforms/" 2>/dev/null || true
    [[ -e "${PLUG_DIR}/styles/libqmacstyle.dylib" ]] || \
        cp -av "${plugs}/styles/libqmacstyle.dylib"   "${PLUG_DIR}/styles/"   2>/dev/null || true
    [[ -e "${PLUG_DIR}/imageformats/libqicns.dylib" ]] || \
        cp -av "${plugs}/imageformats/libqicns.dylib" "${PLUG_DIR}/imageformats/" 2>/dev/null || true
done

##############################################################################
# 5.  FIRST macdeployqt pass (sets IDs & rpaths)                             #
##############################################################################
"$MACDEPLOYQT" "$APP_DIR" \
    -always-overwrite \
    -qmlimport -qmldir="$ROOT_DIR/src/Gui" \
    -verbose=2

##############################################################################
# 6.  Bundle helper apps (QtWebEngine, etc.)                                 #
##############################################################################
find "${LIB_DIR}" -type d -name "*.app" | while read -r helper; do
    "$MACDEPLOYQT" "$helper" -always-overwrite -verbose=1 || true
done

##############################################################################
# 7.  BRING IN project-specific libs & data                                  #
##############################################################################
# 7a. runtime libs (built by FreeCAD/ARCHI)  → Resources/lib
rsync -a "${INSTALL_DIR}/lib/" "${LIB_DIR}/"

# 7b. data resources
rsync -a "${INSTALL_DIR}/share/" "${RES_DIR}/share/"
rsync -a "${INSTALL_DIR}/Mod/"   "${RES_DIR}/Mod/"
rsync -a "${INSTALL_DIR}/Ext/"   "${RES_DIR}/Ext/"

# ---  duplicates expected by FreeCAD bootstrapper --------------------------
ln -snf "Resources/Mod"   "${APP_DIR}/Contents/Mod"
ln -snf "Resources/share" "${APP_DIR}/Contents/share"
ln -snf "Resources/Ext"   "${APP_DIR}/Contents/Ext"

# 7c. optional complete conda env — comment out if you maintain a whitelist
rsync -a --exclude='*.a' --exclude='include/' "${CONDA_PREFIX}/" "${RES_DIR}/"

##############################################################################
# 8.  HOUSE-KEEPING before signing                                           #
##############################################################################
# 8a. delete Qt 5 artefacts
find "${LIB_DIR}" -name 'libQt5*.dylib' -delete
find "${PLUG_DIR}" -name 'libQt5*.dylib' -delete

# 8b. remove static/runtime libs that anger codesign
find "${LIB_DIR}" -name 'libclang_rt*' -o -name 'libperl*.dylib' -o -name 'libtinfo*.dylib' -delete
##############################################################################
# 9.  RELINK everything away from $CONDA_PREFIX                              #
##############################################################################
fix_one_file() {
  local f="$1"
  while read -r old _; do
    [[ "$old" == *"${CONDA_PREFIX}"* ]] || continue
    install_name_tool -change "$old" "@loader_path/../Frameworks/$(basename "$old")" "$f" || true
  done < <(otool -L "$f" | tail -n +2)
  install_name_tool -delete_rpath "${CONDA_PREFIX}/lib" "$f" 2>/dev/null || true
}
export -f fix_one_file
find "${APP_DIR}/Contents" -type f \( -name '*.dylib' -o -name '*.so' -o -perm -111 \) -print0 |
  xargs -0 -n1 -P "$(sysctl -n hw.ncpu)" bash -c 'fix_one_file "$0"'

# main binary needs explicit rpath
install_name_tool -add_rpath "@loader_path/../Frameworks" "${MACOS_DIR}/${APP_NAME}" || true

##############################################################################
# 10. VERIFY – abort only *now* if anything still leaks                       #
##############################################################################
if otool -L "${APP_DIR}"/Contents/**/** | grep -Fq "${CONDA_PREFIX}"; then
  echo "❌  Still found hard-coded references to the build environment!" >&2
  exit 1
fi

##############################################################################
# 11. qt.conf, Info.plist, icon                                              #
##############################################################################
cat > "${RES_DIR}/qt.conf" <<'EOF'
[Paths]
Plugins    = PlugIns
QmlImports = qml
EOF
ln -sf "../Resources/qt.conf" "${MACOS_DIR}/qt.conf"

INFO_TEMPLATE="${ROOT_DIR}/${INFO_TEMPLATE_REL}"
ICNS_FILE="${ROOT_DIR}/${ICNS_FILE_REL}"
ENTITLEMENTS="${ROOT_DIR}/${ENTITLEMENTS_REL}"
DMG_BG="${ROOT_DIR}/${DMG_BG_REL}"

cp "${INFO_TEMPLATE}" "${APP_DIR}/Contents/Info.plist"
plutil -replace CFBundleExecutable         -string "${APP_NAME}"  "${APP_DIR}/Contents/Info.plist"
plutil -replace CFBundleShortVersionString -string "${VERSION}"   "${APP_DIR}/Contents/Info.plist"
plutil -replace CFBundleVersion            -string "${VERSION}"   "${APP_DIR}/Contents/Info.plist"
plutil -replace CFBundleIconFile           -string "Archi"        "${APP_DIR}/Contents/Info.plist"
cp "${ICNS_FILE}" "${RES_DIR}/Archi.icns"

##############################################################################
# 12. clean Python caches                                                    #
##############################################################################
find "${RES_DIR}" -name '__pycache__' -prune -exec rm -rf {} +
find "${RES_DIR}" -name '*.py[co]' -delete
##############################################################################
# 12.  sitecustomize.py – make Python see Frameworks & Resources/lib         #
##############################################################################
PYVER=$("${MACOS_DIR}/${APP_NAME}" --console Python - <<'PY'
import sysconfig, sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")
PY
) || PYVER=$(python -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")')

SITE_DIR="${RES_DIR}/lib/python${PYVER}"
mkdir -p "${SITE_DIR}"

cat > "${SITE_DIR}/sitecustomize.py" <<'PY'
import os, sys
bundle_root = os.path.abspath(os.path.join(__file__, *([os.pardir] * 5)))  # …/Contents
fw = os.path.join(bundle_root, "Frameworks")
reslib = os.path.join(bundle_root, "Resources", "lib")
for p in (fw, reslib):
    if p not in sys.path:
        sys.path.insert(0, p)
PY

echo "✅  sitecustomize.py installed for Python ${PYVER}"
##############################################################################
# 13.  DEEP code-sign & timestamp                                            #
##############################################################################
unset CODESIGN_BIN                         # 1  forget the conda override
CODESIGN_BIN=/usr/bin/codesign             # 2  hard-wire the real path
export CODESIGN_BIN

"$CODESIGN_BIN" --deep --force --options runtime \
                --entitlements "${ENTITLEMENTS}" \
                --timestamp \
                "${APP_DIR}"

##############################################################################
# 14.  CREATE (optionally sign) DMG                                          #
##############################################################################
# dmgbuild example (replace as needed)
# dmgbuild -s "${ROOT_DIR}/package/rattler-build/osx/dmg_settings.py" \
#          "ARCHI" "${BUILD_DIR}/${APP_NAME}-${VERSION}.dmg"

echo "✅  ${APP_NAME}.app is ready in ${APP_DIR}"